package setDemo;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class Driver {

	public static void main(String[] args) {
		Sets o = new Sets();
		// TODO Auto-generated method stub
		Set<Integer> st = new LinkedHashSet<>() ;
		
		 Random random = new Random();
	      
	        
	        for (int i = 0; i < 10; i++) {
	            int randomNumber = random.nextInt(20)+1;
	             
	            st.add(randomNumber);  
			}

	System.out.println("Set is : "+st);
		
	   
      System.out.println("Sorted Set: " +o.bubbleSortSet(st) );
	        
      
      
    
      Set<Integer> s1 = new HashSet<>(15) ;Set<Integer> s2 = new HashSet<>(15) ;
    
      while (s1.size() < 15) {
   	  
   	   int r =  (int)Math.floor(Math.random() * (60 - 20 + 1) + 20);   
          s1.add(r);  
		}
      while (s2.size() < 15) {
   	   int r1 =  (int)Math.floor(Math.random() * (70 - 30 + 1) + 30);          
          s2.add(r1);  
		}

      System.out.println(s1);System.out.println(s2);
      System.out.println("Intersection " + o.intersection(s1,s2));
       
      Set<Integer> u = new HashSet<>(20) ;Set<Integer> s = new HashSet<>(20) ;
      
      while (u.size() < 20) {
   	  
   	   int r =  (int)Math.floor(Math.random() * (60 - 10 + 1) + 10);   
          u.add(r);  
		}
      while (s.size() < 20) {
   	   int r1 =  (int)Math.floor(Math.random() * (60 - 10 + 1) + 10);          
          s.add(r1);  
		}
      System.out.println(u);System.out.println(s);
      System.out.println("Set Compliment " + o.setCompliment(u,s));
//      
      Set ts = new TreeSet<>();
      Set hs = new HashSet<>();
      Set ls = new LinkedHashSet<>();
      
       o.addAll(ts, hs, ls);
	
	}
	}


