package setDemo;

 
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;


public class Sets {

 
   public static Set<Integer> bubbleSortSet(Set<Integer> s1) {
	     
		 
		int a = 0;
		while(a <  s1.size() - 1)
		{	
			int d = 0,j=0;
			while(j< s1.size()-a-1)
			{
				Set<Integer> no = new LinkedHashSet<>();
				Iterator<Integer> r = s1.iterator();
				int h;
				for(h = 0;r.hasNext();h=h+2) 
				{	
					for(int q=0;q < d;q++) 
					{
						no.add(r.next());
						h++;					
					}
					
					int	m = r.next();
					int n = r.next();
					
					if(m>n) 
					{
					    int w; 
					    w= m;
					    m = n;
					    n = w;
					    no.add(m);
					    no.add(n);
					}
					else 
					{
						no.add(m);
						no.add(n);
					}
				
					break;
				}
				Iterator<Integer> rr = s1.iterator();
				
					  for(int z=0;rr.hasNext();z++)
					  {
						  		if(z<h) {
						  			rr.next();
						  			continue;
						  		}	
						  		no.add(rr.next()); 
					  }
					  d++;
					s1=no;
					j++;
			}		
				a++;
		
			}
		
		
		
		
		return s1;
		
		
		}
	
		
               
	



	
		
	
public static  Set  intersection(Set<Integer> s1 , Set<Integer> s2) {
	Set s = new HashSet();
  
	for(Integer i : s1) {
		for(Integer j : s2) {
		if(i == j) {
			s.add(i);
		}
			
		}
	 }return s;
}
public static  Set  setCompliment(Set<Integer> s1 , Set<Integer> s2) {
//	Set   s = new HashSet();
//      
//	Iterator<Integer> it = s1.iterator();
//	
//	while(it.hasNext()){
//		
//		if(!s2.contains(it.next())) {
//			s.add(it.next());
//		
//		}
//
//	
	Set  ss = new LinkedHashSet<Integer>(s1);
	Iterator r = s1.iterator();
	   while(r.hasNext()) {
		int a = (int) r.next();
		Iterator rr = s2.iterator();
		while(rr.hasNext()) {
			if(a==(int)rr.next()) {
				ss.remove(a);
			}
		}
	}
	return ss;
}
	

public static  void  addAll(Set ts, Set hs, Set ls)  {

	Random random = new Random();
    
    long n = 15;
	long nanoTime1 = System.nanoTime();
    for (int i = 0; i < n; i++) {
        int randomNumber = random.nextInt(100)+1;
         
        ts.add(randomNumber);  
	}long nanoTime2 = System.nanoTime();
	
	long a = nanoTime2-nanoTime1;
	System.out.println("For size 15 :"+a);
 
		long nanoTime12 = System.nanoTime();
	    for (int i = 0; i < n; i++) {
	        int r = random.nextInt(100)+1;
	         
	        hs.add(r);  
		}long nanoTime22 = System.nanoTime();
		long b = nanoTime22-nanoTime12;
		System.out.println("For size 15 :"+b);

		
	 
		long nanoTime13 = System.nanoTime();
	    for (int i = 0; i < n; i++) {
	        int rr = random.nextInt(100)+1;
	         
	        ls.add(rr);  
		}long nanoTime23 = System.nanoTime();
		
		long c = nanoTime23-nanoTime13;
		System.out.println("For size 15 :"+c);

		
	
		
		 long n1 = 10000;
			long nanoTime11 = System.nanoTime();
		    for (int i = 0; i < n1; i++) {
		        int randomNumber = random.nextInt(100)+1;
		         
		        ts.add(randomNumber);  
			}long nanoTime21 = System.nanoTime();
			
			long a1 = nanoTime21-nanoTime11;
			System.out.println("For size 10000 :"+a1);
		 
				long nanoTime121 = System.nanoTime();
			    for (int i = 0; i < n1; i++) {
			        int r = random.nextInt(100)+1;
			         
			        hs.add(r);  
				}long nanoTime221 = System.nanoTime();
				long b1 = nanoTime221-nanoTime121;
				System.out.println("For size 10000 :"+b1);

			 
				long nanoTime131 = System.nanoTime();
			    for (int i = 0; i < n1; i++) {
			        int rr = random.nextInt(100)+1;
			         
			        ls.add(rr);  
				}long nanoTime231 = System.nanoTime();
				
				long c1 = nanoTime231-nanoTime131;
				System.out.println("For size 10000 :"+c1);
		
		
		
		
		
				 long n2 = 100000;
					long nanoTime123 = System.nanoTime();
				    for (int i = 0; i < n2; i++) {
				        int randomNumber = random.nextInt(100)+1;
				         
				        ts.add(randomNumber);  
					}long nanoTime223 = System.nanoTime();
					
					long a2 = nanoTime223-nanoTime123;
					System.out.println("For size 100000 :"+a2);
				 
						long nanoTime122 = System.nanoTime();
					    for (int i = 0; i < n2; i++) {
					        int r = random.nextInt(100)+1;
					         
					        hs.add(r);  
						}long nanoTime222 = System.nanoTime();
						long b2 = nanoTime222-nanoTime122;
						System.out.println("For size 100000 :"+b2);

					 
						long nanoTime132 = System.nanoTime();
					    for (int i = 0; i < n2; i++) {
					        int rr = random.nextInt(100)+1;
					         
					        ls.add(rr);  
						}long nanoTime232 = System.nanoTime();
						
						long c2 = nanoTime232-nanoTime132;
						System.out.println("For size 100000 :"+c2);

		
		
						
						 long n5 = 1000000;
							long nanoTime15 = System.nanoTime();
						    for (int i = 0; i < n5; i++) {
						        int randomNumber = random.nextInt(100)+1;
						         
						        ts.add(randomNumber);  
							}long nanoTime25 = System.nanoTime();
							
							long a4 = nanoTime25-nanoTime15;
							System.out.println("For size 1000000 :"+a4);
						 
								long nanoTime125 = System.nanoTime();
							    for (int i = 0; i < n5; i++) {
							        int r = random.nextInt(100)+1;
							         
							        hs.add(r);  
								}long nanoTime225 = System.nanoTime();
								long b4 = nanoTime225-nanoTime125;
								System.out.println("For size 1000000 :"+b4);

							 
								long nanoTime135 = System.nanoTime();
							    for (int i = 0; i < n5; i++) {
							        int rr = random.nextInt(100)+1;
							         
							        ls.add(rr);  
								}long nanoTime235 = System.nanoTime();
								
								long c5 = nanoTime235-nanoTime135;
								System.out.println("For size 1000000 :"+c5);

		
								
								
								
								 long n6 = 500000000;
									long nanoTime16 = System.nanoTime();
								    for (int i = 0; i < n6; i++) {
								        int randomNumber = random.nextInt(100)+1;
								         
								        ts.add(randomNumber);  
									}long nanoTime26 = System.nanoTime();
									
									long a6 = nanoTime26-nanoTime16;
									System.out.println("For size 500000000 :"+a6);
								 
										long nanoTime126 = System.nanoTime();
									    for (int i = 0; i < n6; i++) {
									        int r = random.nextInt(100)+1;
									         
									        hs.add(r);  
										}long nanoTime226 = System.nanoTime();
										long b6 = nanoTime226-nanoTime126;
										System.out.println("For size 500000000 :"+b6);

									 
										long nanoTime136 = System.nanoTime();
									    for (int i = 0; i < n6; i++) {
									        int rr = random.nextInt(100)+1;
//									         
									        ls.add(rr);  
										}long nanoTime236 = System.nanoTime();
										
										long c6 = nanoTime236-nanoTime136;
										System.out.println("For size 500000000 :"+c6);

										
										long n7 = 1000000000;
										long nanoTime17 = System.nanoTime();
									    for (int i = 0; i < n7; i++) {
									        int randomNumber = random.nextInt(100)+1;
									         
									        ts.add(randomNumber);  
										}long nanoTime27 = System.nanoTime();
										
										long a7 = nanoTime27-nanoTime17;
										System.out.println("For size 1000000000 :"+a7);
									 
											long nanoTime127 = System.nanoTime();
										    for (int i = 0; i < n7; i++) {
										        int r = random.nextInt(100)+1;
										         
										        hs.add(r);  
											}long nanoTime227 = System.nanoTime();
											long b7 = nanoTime227-nanoTime127;
											System.out.println("For size 1000000000 :"+b7);

										 
											long nanoTime137 = System.nanoTime();
										    for (int i = 0; i < n7; i++) {
										        int rr = random.nextInt(100)+1;
										         
										        ls.add(rr);  
											}long nanoTime237 = System.nanoTime();
											
											long c7 = nanoTime237-nanoTime137;
											System.out.println("For size 1000000000 :"+c7);
									
									
	
	
}}






 






 
	
	
	
	
	
	
	
	
	
	
	
	
