package Regex;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExpOverlap {

	public static void main(String args[]) {
		
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter regular expression: ");
	String pattern1 = sc.nextLine();
	System.out.print("Enter the string: ");
	String text = sc.nextLine();
	
	Pattern pattern = Pattern.compile(pattern1);
	int j ;
	for(int i = 0; i < text.length(); i++) {
		 j = i;
		try {
			while(j < text.length()) {
				Matcher matcher = pattern.matcher(text.substring(i, j));
				if(matcher.matches()) {
					System.out.println(matcher.group() + " is found at index " + i);
				}
				j++;
			}
		}catch(Exception e) {
			System.out.println("Execption thrown");
		}
	}
}

}