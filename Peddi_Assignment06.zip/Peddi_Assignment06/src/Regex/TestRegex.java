package Regex;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestRegex {

	public static  void TestRegExp(String text, String text1){
		 Pattern pattern = Pattern.compile(text1);
	        Matcher matcher = pattern.matcher(text);
	        int i = 1;
		while (matcher.find()) {
            System.out.println(i + ") " + matcher.group() + " is found at index " + matcher.start());
            i++;
            
        }
        if (i == 1) {
            System.out.println("No matches found.");
        }
    }
		
	 public static void main(String[] args) {
//	        String text = "abaaaabbbaabba";
//	        String text1 = "ab";
	      

	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter the String: ");
	        String text = sc.nextLine();
	        System.out.println("Enter the regular expression:");
	        String text1 = sc.nextLine();
	        TestRegExp(text, text1);
	        
  text = "abaaaaabbbaabbaa";
	        text1 = "ab+";
	        TestRegExp(text, text1);
	    }
	}
 
	
	
	
	
	
	
 
