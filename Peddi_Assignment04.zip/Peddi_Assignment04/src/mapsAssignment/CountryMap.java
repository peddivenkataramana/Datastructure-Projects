package mapsAssignment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CountryMap {
	private Map<String, Details> m;

	public CountryMap() {
		m = new LinkedHashMap<>();
	}

	public void addCountry(String name, String capital, long population, double area) {
		m.put(name, new Details(name, capital, population, area));
	}

	public void displayAllCountries() {
		Set<String> n = m.keySet();
		for (String a : n) {
			 
			displayCountry(a);
			 
		}
	}

	public void displayCountry(String n) {
		Details d = m.get(n);
		if (d != null) {
			System.out.println("Name: " + d.getName());
			System.out.println("Capital: " + d.getCapital());
			System.out.println("Population: " + d.getPopulation());
			System.out.println("Area: " + d.getArea());
		} else {
			System.out.println("Country not found.");
		}
	}

	public void removeCountry(String n) {
		Details d = m.remove(n);
		if (d != null) {
			System.out.println("Removing country  " + d.getName() + " and searching for it");
			searchCountry(n);
		} else {
			System.out.println("Country not found for Removing.");
		}
	}

	public void searchCountry(String n) {
		if (!m.containsKey(n)) {
			System.out.println("Country not found");
		} else {
			System.out.println("Country Name "+n+" found");
		}
	}

	public void getTotalPopulation() {
		long p = 0;
		for (Details d : m.values()) {
			p += d.getPopulation();
		}
		System.out.println("Total population: " + p);
	}

	public void getLargestCountry() {
		double a = Double.MIN_VALUE;
		String l = "";
		for (Details d : m.values()) {
			if (d.getArea() > a) {
				a = d.getArea();
				l = d.getName();
			}
		}
		System.out.println("Largest country: " + l + " (" + a + ")");
	}

	public void displayCountriesByPopulation() {
		List<Details> l = new ArrayList<>(m.values());
		Collections.sort(l, new Comparator<Details>() {
			@Override
			public int compare(Details a, Details b) {
				return Long.compare(b.getPopulation(), a.getPopulation());
			}
		});
		System.out.println("Countries by population:");
		for (Details d : l) {
			System.out.println(d.getName() + " - " + d.getPopulation());
		}
	}

	public void displayCountriesByArea() {
		List<Details> l = new ArrayList<>(m.values());
		Collections.sort(l, new Comparator<Details>() {
			
			public int compare(Details a, Details b) {
				return Double.compare(a.getArea(), b.getArea());
			}
		});
		System.out.println("Countries by area:");
		for (Details d : l) {
			System.out.println(d.getName() + ": " + d.getArea());
		}
	}
}
