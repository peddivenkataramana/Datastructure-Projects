package mapsAssignment;

public class Details {
	private String n;
    private String c;
    private long p;
    private double a;
    

    public Details(String name, String capital, long population, double area) {
        n = name;
        c = capital;
        p = population;
        a = area;
    }

    public String getName() {
        return n;
    }

    public String getCapital() {
        return c;
    }
    
    public long getPopulation() {
        return p;
    }

    public double getArea() {
        return a;
    }

    
}
