package mapsAssignment;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Dictionary {

	public static void main(String[] args) {
		

	Map<String,String> m = new HashMap<>();
	
	
	 Scanner sc = new Scanner(System.in);
	 
 
	

	while(true) {
		System.out.print("Enter a word (or 'q' to quit): ");

		 String a = sc.nextLine();
		 if(a.equalsIgnoreCase("q")) {
			
					 break;
				
			 
		 }else {
		 System.out.print("Enter the definition: ");
		 String b = sc.nextLine();
		 m.put(a, b);}
	}
	
	while(true) {
		int a=0;
		System.out.print("Enter a word to search for (or 'q' to quit): ");
		 String c = sc.nextLine();
		 if(c.equalsIgnoreCase("q")) {break;}
		  

		 
			for(var m1:m.entrySet()){
				a++;
				if(m1.getKey().equalsIgnoreCase(c)) {
				  System.out.println("The definition of " +m1.getKey()+" is: " +m1.getValue());
				  break;
				}
				if(a==m.size()) 
					System.out.println(c + " is not in the dictionary.");
			} 
	
		 }}
	
	
	
	
}
