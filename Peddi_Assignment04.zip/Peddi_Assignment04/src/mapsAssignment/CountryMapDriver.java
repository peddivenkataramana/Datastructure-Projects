package mapsAssignment;

public class CountryMapDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CountryMap m = new CountryMap();
		m.addCountry("USA", "Washington DC",  328200000,9834000.0);
		m.addCountry("China", "Beijing", 1393000000, 9597000.0);
		m.addCountry("India", "New Delhi", 1366000000, 3287000.0);
		m.addCountry("Russia", "Moscow", 146700000, 1.7125E7);
		m.addCountry("Brazil", "Brasília", 213800000, 8515767.0);
		m.displayAllCountries();
		System.out.println("********************");
		m.removeCountry("Russia");
		System.out.println("********************");
		m.getTotalPopulation();
		System.out.println("********************");
		m.getLargestCountry();
		System.out.println("********************");
		m.displayCountriesByPopulation();
		System.out.println("********************");
		m.displayCountriesByArea();
	}

}
