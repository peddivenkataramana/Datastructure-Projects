package com.example.DMS.repository;

import com.example.DMS.Models.Dog;
import org.springframework.data.repository.CrudRepository;

public interface DogRepository extends CrudRepository<Dog,Integer>{
	

}
