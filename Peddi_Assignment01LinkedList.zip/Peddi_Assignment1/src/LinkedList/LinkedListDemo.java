package LinkedList;

public class LinkedListDemo {
	public static void addLastNode(int v, Node h) {
		
		Node a = new Node(v);
		
		while(h.next==null) 
		{
			h.next = a;
		}
		a.next = null;
		a.prev = h.next;
		
	}
	public static void addNode(Node n, Node b)
	{
		Node c = new Node(88);
		c.next = b;
		c.prev = n;
		n.next = c;
	}
	public static void main(String[] args) {
	Node head = new Node(36);
	System.out.println("Address of head: "+head);
	System.out.println("Data of head: "+head.data);
	System.out.println("Next of head: "+head.next);
	Node secondNode = new Node(78);
	System.out.println("Address of SecondNode: "+secondNode);
	System.out.println("Data of secondNode: "+secondNode.data);
	System.out.println("Next of secondNode: "+secondNode.next);
	Node thirdNode = new Node(99);
	System.out.println("Address of thirdNode: "+thirdNode);
	System.out.println("Data of thirdNode: "+thirdNode.data);
	System.out.println("Next of thirdNode: "+thirdNode.next);
	head.next = secondNode;
	secondNode.next = thirdNode;
	Node p = head;
	int sum = 0;
	int count = 0;
	while(p!=null) {
	System.out.println("Inside loop: "+p.data);
	sum = sum+p.data;
	count = count+1;
	p = p.next;
	}
	System.out.println("Count: "+count);
	System.out.println("Sum: "+sum);
	Node newhead = new Node(22);
	System.out.println("Address of newhead: "+newhead);
	System.out.println("Data of newhead: "+newhead.data);
	System.out.println("Next of newhead: "+newhead.next);
	Node updatedhead = linkbothlists(head,newhead);
	Node r = updatedhead;
	while(r!=null) {
	System.out.println("Inside loop with updated head: "+r.data);
	r = r.next;
	}
	System.out.println();
	System.out.println("Elements of the list in the backward direction");
	head.printReverse(updatedhead);
	System.out.println("\n");
	
	//Node n1= new Node(43);
	 
	//System.out.println();
	//System.out.println(addLastNode(updatedhead, n1).data);
	System.out.println("New node is added at the end of the list");
	addLastNode(43, thirdNode);
	head.print(newhead);
	
	
	System.out.println("\n");
	addNode(newhead, head);
	System.out.println("New node is added after the head ");
	head.print(newhead);
	
}
	
	public static Node linkbothlists(Node h, Node nh)
	{
	nh.next = h;
	return nh;
	}
	 
	}
	 