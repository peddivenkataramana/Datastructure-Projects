package LinkedList;

public class Node {
 
	int data;
	Node next;
	Node prev;
	
	public Node(int num) {
		data = num;
		next = null;
		prev = null;
	}
	
	public void printReverse(Node head)
    {
        if (head == null) return;
        printReverse(head.next);
        
        System.out.print(head.data+" ");
        
 
    }
	public  void print(Node a) 
	{
		while(a!=null) {
			System.out.print(a.data+" ");
			a = a.next;	
			
			 
			}
	}
	 
   
}
    


