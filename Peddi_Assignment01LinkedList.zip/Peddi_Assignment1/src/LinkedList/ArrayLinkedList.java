package LinkedList;
import java.util.LinkedList;
import java.util.Scanner;

public class ArrayLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	LinkedList[] arrayLinkedList  = new LinkedList[5];
	
	for(int i =0;i<arrayLinkedList.length;i++) {
	System.out.println(arrayLinkedList[i]);}
	System.out.println("Enter name :");
	 for (int i = 0; i < 5; i++) {
         arrayLinkedList[i] = new LinkedList<Integer>();
     
	
	 Scanner s = new Scanner(System.in);
	 
	
		for(int j = 0; j<3;j++) {
		
			String n = s.nextLine();
			arrayLinkedList[i].add(n) ;
		}
		}

	 
	for(int i = 0; i<arrayLinkedList.length;i++) {
		 
		System.out.println("\n"+arrayLinkedList[i]);
		
		
	}
	
	
	
	
	
	
	
	
	
	
	}
	
}
