package LinkedList;
import java.util.LinkedList;
import java.util.Scanner;
public class LinkedListAPI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		LinkedList<Integer> employee = new LinkedList<Integer>();
		
		employee.add(12);
		employee.add(35);
		employee.add(43);
		employee.add(26);
		employee.add(17);
		employee.add(19);
		
		
		System.out.println("Employees at the beginning of the year: \n"+employee);
		
		employee.remove(2);
		employee.remove(3);
		
		System.out.println("Employees after being retired:\n"+employee);
		
		 for (int k = 0, j = employee.size() - 1; k < j; k++)
	        {
	            employee.add(k, employee.remove(j));
	        }
		
		System.out.println("Employees in the reverse order:\n"+employee);
		
		 
		if(employee.contains(35) ) {
			System.out.println("Employees with the id 35 is present or not: "+ employee.contains(35) );
				}
		else {
			System.out.println("Employees with the id 35 is present or not: "+ employee.contains(35) );
				}
		
		 if(employee.contains(23)) {
			System.out.println("Employees with the id 23 is present or not: "+ employee.contains(23));
			
		}
		 else{
				System.out.println("Employees with the id 23 is present or not: "+ employee.contains(23));
				
			}
			
		 if(employee.contains(26)) {
				System.out.println("Employees with the id 26 is present or not: "+ employee.contains(26));
				
			}
		 else {
				System.out.println("Employees with the id 26 is present or not: "+ employee.contains(26));
				
			}
		 if(employee.contains(8)) {
				System.out.println("Employees with the id 08 is present or not: "+ employee.contains(8));
				
			}
		 else {
				System.out.println("Employees with the id 08 is present or not: "+ employee.contains(8));
				
			}
				
		 for (int k = 0, j = employee.size() - 1; k < j; k++)
	        {
	            employee.add(k, employee.remove(j));
	        }
		 
		 for(int i = 0 ; i<employee.size();i++) {
			 employee.set(i, employee.get(i)+5);
		 }
		 System.out.println("Incrementing all the values in the list by 5\n"+employee);
		 
		
		 System.out.println("Enter a value between  0 and 4");
		 
		 Scanner s = new Scanner(System.in);
		 
		 int k = s.nextInt();
		 
		System.out.println("Displaying the last 4 elements in list\n"+employee.subList(employee.size() - k, employee.size()));
		
		System.out.println("Enter a value between  0 and 6");
		k = s.nextInt();
		
		System.out.println("Displaying the first 3 elements in list\n"+employee.subList(0, k));
				 
		 
		if(employee.contains(25) ) {
			System.out.println("25 is present in the list or not: "+ employee.contains(25) );
				}
		else {
			System.out.println("25 is present in the list or not: "+ employee.contains(25) );
				}
		 
		if(employee.contains(32) ) {
			System.out.println("32 is present in the list or not: "+ employee.contains(32) );
				}
		else {
			System.out.println("32 is present in the list or not: "+ employee.contains(32) );
				}
		
		 
		 
		 
		 
		 
		 
	}

}
