package Tree;

import java.util.Random;

public class TreeDriver {
	 

	public static void main(String[] args) {
		
		System.out.println("Qs 3 and 4");
		System.out.println("10 Records ");
		Tree o=new Tree();
		Node ob=new Node(3,1,2);
		o.insert(ob,1,2,2);
		o.insert(ob,5,2,2);
		o.insert(ob,2,2,2);
		o.insert(ob,4,1,2);
		o.insert(ob,5,1,1);
		o.insert(ob,5,3,2);
		o.insert(ob,5,3,1);
		o.insert(ob,5,3,3);
		o.insert(ob,5,2,3);
		System.out.println("Traversal 1");
		o.traversal(ob);
		
		System.out.println("13 Records ");
		Tree trr= new Tree();
		Node ob1=new Node(5,2,2);
		trr.insert(ob1, 5, 2, 3);
		trr.insert(ob1, 5, 2, 4);
		trr.insert(ob1, 5, 2, 5);
		trr.insert(ob1, 5, 3, 1);
		trr.insert(ob1, 5, 3, 2);
		trr.insert(ob1, 5, 3, 99);
		trr.insert(ob1, 7, 4, 3);
		trr.insert(ob1, 5, 3, 87);
		trr.insert(ob1, 6, 4, 3);
		trr.insert(ob1, 1, 7, 4);
		trr.insert(ob1, 5, 4, 3);
		trr.insert(ob1, 5, 4, 1);
		System.out.println("Traversal 2");
		trr.traversal(ob1);
		
		
		
		
		
		
		
		
		
		
		
		
		System.out.println("Qs 5");
		
		
		Random rand = new Random();
		
		Tree tr=new Tree();
		
		int a;
		int b;
		int c;
		 
		
	  

		
		for(int i=0;i<10;i++) {
					a=rand.nextInt(999-100)+100;
					b=rand.nextInt(999-100)+100;
					c=rand.nextInt(9999-1000)+1000;
					tr.insert(ob1, a,b,c);
			
		}
		
		
		System.out.println("traversal 3");
		tr.traversal(ob1);
		
		
		Tree tr1=new Tree();
		
		int a1;
		int b1;
		int c1;
		
		
		for(int j=0;j<100;j++) {
			a1=rand.nextInt(999-100)+100;
			b1=rand.nextInt(999-100)+100;
			c1=rand.nextInt(9999-1000)+1000;
			tr1.insert(ob1, a1,b1,c1);
		}System.out.println("traversal 4");
			tr1.traversal(ob1);
			

			Tree tr3=new Tree();
			
			int a3;
			int b3;
			int c3;
			
			
			for(int j=0;j<100;j++) {
				a3=rand.nextInt(999-100)+100;
				b3=rand.nextInt(999-100)+100;
				c3=rand.nextInt(9999-1000)+1000;
				tr1.insert(ob1, a3,b3,c3);
			}System.out.println("traversal 5");
				tr1.traversal(ob1);
				


	}}
