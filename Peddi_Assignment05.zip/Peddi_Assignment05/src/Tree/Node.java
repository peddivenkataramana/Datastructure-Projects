package Tree;

public class Node {
	
	
    Node l;
    Node r;
    Node h;
    int[] a=new int[3]; 
    
    Node(int set1,int set2,int set3){ 
        this.a[0] = set1; 
        this.a[1] = set2; 
        this.a[2] = set3; 
        l = null; 
        r = null; 
    } 
	
	@Override
	public String toString() {
		return "("+this.a[0]+","+this.a[1]+","+this.a[2]+")";
	}
}

