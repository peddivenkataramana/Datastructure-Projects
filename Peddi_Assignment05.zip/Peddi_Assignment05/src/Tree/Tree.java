package Tree;

public class Tree {
	
	public void insert(Node node, int a,int a1,int a2) {
		
        if (a < node.a[0]) {
        	if (node.l != null) { 
        		insert(node.l, a,a1,a2); } 
        	else { System.out.println("Inserted " +"("+ a+","+a1+","+a2 +")"+ " to l of " + node.toString()); 
        	node.l = new Node(a,a1,a2); } } 
        else if (a > node.a[0]) {
          if (node.r != null) {
            insert(node.r, a,a1,a2);
          } else {
            System.out.println("Inserted " +"("+ a+","+a1+","+a2 +")"+ " to r of "+ node.toString());
            node.r = new Node(a,a1,a2);
          }
        }
        else if(a==node.a[0]) {
        	if(node.h==null) {
        		node.h=new Node(node.a[0],node.a[1],node.a[2]);
        		insert(node.h,a1,a2);
        	}
        	else {
        		insert(node.h,a1,a2);
        	}
        }
	}
	public void insert(Node node,int a1,int a2) {
		if (a1 < node.a[1]) {
        	if (node.l != null) { 
        		insert(node.l, a1,a2); } 
        	else { System.out.println(" Inserted " + "("+ node.a[0]+","+a1+","+a2 +")"+ " to l of " + node.toString()); 
        	node.l = new Node(node.a[0],a1,a2); } } 
        else if (a1 > node.a[1]) {
          if (node.r != null) {
            insert(node.r,a1,a2);
          } else {
            System.out.println(" Inserted " + "("+ node.a[0]+","+a1+","+a2 +")"+ " to r of "+ node.toString());
            node.r = new Node(node.a[0],a1,a2);
          }
        }
        else if(a1==node.a[1]) {
        	if(node.h==null) {	
        		node.h=new Node(node.a[0],node.a[1],node.a[2]);
        		insert(node.h,a2);}
        	else {
        		insert(node.h,a2);
        	}
        }
		}
	public void insert(Node node,int a2) {
		if (a2 < node.a[2]) {
        	if (node.l != null) { 
        		insert(node.l, a2); } 
        	else { System.out.println("  Inserted " + "("+ node.a[0]+","+node.a[1]+","+a2 +")"+ " to l of " + node.toString()); 
        	node.l = new Node(node.a[0],node.a[1],a2); } } 
        else if (a2 > node.a[2]) {
          if (node.r != null) {
            insert(node.r,a2);
          } else {
            System.out.println("  Inserted " + "("+ node.a[0]+","+node.a[1]+","+a2 +")"+ " to r of "     + node.toString());
            node.r = new Node(node.a[0],node.a[1],a2);
          }
        }
	}
	public void traversal(Node node) {
		if(node==null) {
			return;
		}
		traversal(node.l);
		if(node.h!=null) {
			traversal(node.h);
		}
		else {
			System.out.println(node.a[0]+" "+node.a[1]+" "+node.a[2]);
		}
		traversal(node.r);
			
	}

}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
 
