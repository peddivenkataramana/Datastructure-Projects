package Stack;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

public class Stacks {
	
	 
	 

	public static void main(String[]args) {
		
		 
		Stack<Integer> S = new Stack<Integer>();
		S.push(11);
		S.push(22);
		S.push(33);
		S.push(44);
		S.push(66);
		S.push(77);
		S.push(88);
		S.push(100);
		S.push(120);
		
		
		System.out.println("Displaying the elements in top down fashion: ");
		for(int i = 0;i<9;i++) {
		 System.out.print(S.pop()+" ");
		}
		 
		S.push(11);
		S.push(22);
		S.push(33);
		S.push(44);
		S.push(66);
		S.push(77);
		S.push(88);
		S.push(100);
		S.push(120);
		
		System.out.println();
		
	    S.pop();
	    
	    
		 
		System.out.println("Displaying if the stack is empty or not");
		
		if(S.isEmpty()) {
			System.out.println("The Stack is  empty");
		}
		else {
			System.out.println("The Stack is not empty");
		}
		
		 
	 
		System.out.println("The position of particular book 22 is " + (S.size()-S.lastIndexOf(22)));
			
		ArrayList<Integer> L = new ArrayList<Integer>();
		
		
		 
		
		 
		for (int i = 3; i >= 0; i--) {
			  L.add(S.remove(i));
			}

			for (int i = 0; i<S.size(); i++) {
			  L.add(S.get(i));
			}
			S.clear();
			System.out.println("Displaying the elements from the obtained Array List");
			System.out.println(L);
		
			PriorityQueue<Integer> Q = new PriorityQueue<Integer>();
			
			for(int i = 0; i <L.size() ;i++) {
				Q.add(L.get(i));
				
			}
			Iterator<Integer>i = Q.iterator();
		 
			System.out.println("Displaying the elements of Q using iterator");
			 while (i.hasNext()) {
		         System.out.print(i.next()+" ");
		      }System.out.println();
		      
			 ArrayDeque<Integer> D = new ArrayDeque<Integer>();
			 

				for(int j = 0; j <L.size() ;j++) {
					D.add(L.get(j));
					
				}
				
			 
			 Iterator<Integer>j = D.iterator();
			 System.out.println("Displaying the elements of D using iterator");
			 while (j.hasNext()) {
		         System.out.print(j.next()+" ");
		      }
			 
			 
			 
			 
	
	}
			 
	
			//  public static Queue<String> stackToqueue(Stack<String> s) {
				 
				  
				 
			//  }
			 
			 
			 
			 
			 
			 
			 
			 
			 
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
