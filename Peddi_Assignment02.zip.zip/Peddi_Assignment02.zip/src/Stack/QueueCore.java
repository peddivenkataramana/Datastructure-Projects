package Stack;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

 
	   
	public class QueueCore {
	   
	    Node head;
	
	static class Node {
	   
	        String data;
	        Node next;
	   
	        Node(String d)
	        {
	            data = d;
	            next = null;
	        }
	    }
	   
	  
	    
	    
	    
	    
	    
	    
	}

 
