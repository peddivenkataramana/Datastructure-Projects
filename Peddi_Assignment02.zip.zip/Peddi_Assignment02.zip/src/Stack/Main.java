package Stack;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

import Stack.QueueCore.Node;

public class Main {
	
	  public static QueueCore stackToqueue(Stack<String> stk)
	    {
	        QueueCore q = new QueueCore();
	        int a=stk.size();
	        for(int i=0;i<a;i++) {
	        Node new_node = new Node(String.valueOf(stk.pop()));
	       
	        if (q.head == null) {
	            q.head = new_node;
	        }
	        else {
	            Node last = q.head;
	            while (last.next != null) {
	                last = last.next;
	            }
	            last.next = new_node;
	        }
	        }
	        return q;

	    }
	    

    public static LinkedList<String> arrayTolinkedlist(String[] l) {
           LinkedList<String> lst = new LinkedList<String>();
           
           for(int i=0;i<l.length;i++) {
           lst.push(l[i]);
           }
           return lst;
       }

    public static Queue<String> linkedlistToqueue(LinkedList<String> st) {
        Queue<String> que = new LinkedList<String>();
        que.addAll(st);
        return que;
    }
    
    public static LinkedList<String> queueTolinkedlist(QueueCore q){
        LinkedList<String> lst = new LinkedList<String>();
        Node n=q.head;
        while(n.next!=null) {
            lst.push(n.data);
            n=n.next;
        }
        return lst;
    }

public static void main(String []args) {
	
	
	Stack<String> s = new Stack<String>();
	
	s.push("q");s.push("w");s.push("e");s.push("r");s.push("t");
	s.push("y");s.push("u");s.push("i");s.push("o");s.push("p");
	
//	 System.out.println("Stack :"+s);

       //stackToqueue(s);
	 
 //      System.out.println("The Queue is : ");
//       printList(stackToqueue(s));
	
    QueueCore q = new QueueCore();
   
     
       System.out.println("Stack: ");
       
       for(int i = s.size()-1;i>=0;i--) {
       System.out.print(s.get(i)+" ");}
       System.out.println();
       
       q = stackToqueue(s);
       
       System.out.println("Queue : ");
       Display(q);
       System.out.println();
      
       String[] str = {"a","b","c","d","e","f","g","h","i","j"};
       
      
       LinkedList<String> z = new LinkedList<String>();
       
       z=arrayTolinkedlist(str);
       
       System.out.println("String : ");
       
       for(int i=0;i<str.length;i++)
          System.out.print(str[i]+" "); System.out.println();
         
          System.out.println("LinkedList: "+z);
          
       
       LinkedList<String> w = new LinkedList<String>();
       
       w=queueTolinkedlist(q);
       
       System.out.println("Queue : ");
       Display(q);System.out.println();
       System.out.println("Linked List : "+w);
     
       
      Queue<String> q1=new LinkedList<String>();
      q1=linkedlistToqueue(z);
      
      System.out.println("LinkedList : "+z);
    
      System.out.println("Queue : "+q1);
           
}



	 

public static void Display(QueueCore q)
{
    Node n = q.head;

     
        while (n != null) {
        System.out.print(n.data + " ");
        n = n.next;
    }
}









}
